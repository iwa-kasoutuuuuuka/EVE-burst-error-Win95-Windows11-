﻿# EVE burst error - Windows 95 Edition - Modern Compatibility Patch
# (EVE burst error Win95版 現代環境互換パッチ)

![Version](https://img.shields.io/badge/Version-Ultimate_Fix-blue)
![Platform](https://img.shields.io/badge/Target-Windows_10/11-brightgreen)

## 💎 概要 / Overview
本パッチは、1997年に発売された Windows 95版 『EVE burst error』 を、最新の Windows 10/11 環境で快適に動作させるための **「現代環境互換レイヤー（Wrapper）」** です。

## 🚀 主な機能 / Key Features
1. **CD-DA エミュレーション / CD Audio Emulation**
2. **実行速度の適正化 / Timing Fix (CPU Throttling)**
3. **マルチメディア・コマンドのフック / Multimedia Hooking**
4. **画面表示の安定化 / Video Stability**

## 📥 導入方法 / How to Install
1. **正規のインストールフォルダを開く**
2. **パッチファイルをコピー**
   - 同梱されている DLL ファイルを、ゲームの実行ファイルと同じ場所にコピーしてください。
3. **ゲームを起動**

## ⚖️ 免責事項と著作権 / Disclaimer & Copyright
本パッケージにはオリジナルデータは一切含まれていません。著作権は権利保持者に帰属します。

---
Produced by Antigravity AI
